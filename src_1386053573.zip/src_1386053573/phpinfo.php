<?php
   phpinfo();
?>
